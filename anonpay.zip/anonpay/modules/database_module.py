import json

def load_users():
    with open('./database/users.json', 'r') as file:
        return json.load(file)

def login_user(username,password):
    users = load_users()
    try:
        for user in users:
            if user.get('username') == username:
                if user.get('password') == password:
                    return True
                return False
    except:
        return False

def get_user_saldo(username):
    users = load_users()
    for user in users:
        if user.get('username') == username:
            saldo = user.get('saldo')
            return int(saldo)

if __name__ == '__main__':
    print('you cannot open this module alone.')