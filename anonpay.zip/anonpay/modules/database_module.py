import json
from flask_login import current_user

def load_users():
    with open('./database/users.json', 'r') as file:
        return json.load(file)

def save_user(user):
    with open('./database/users.json','w') as users_db:
        json.dump(user, users_db, indent=4)

def login_user(username,password):
    users = load_users()
    try:
        for user in users:
            if user.get('username') == username:
                if user.get('password') == password:
                    return True
                return False
    except:
        return False

def register_user(username,password):
    users = load_users()
    for user in users:
        if user.get('username') == username:
            return False
        new_user = {"username": username, "password": password, "saldo": 0}
        users.append(new_user)
        save_user(users)
        return True
        break

def get_user_saldo(username):
    users = load_users()
    for user in users:
        if user.get('username') == username:
            saldo = user.get('saldo')
            return int(saldo)

def convert_value(value):
    payment_str = str(value)
    cleaned_str = ''.join(char for char in payment_str if char.isdigit() or char == ',')
    payment_float = float(cleaned_str.replace(',', '.'))
    payment_rounded = round(payment_float, 2)
    return payment_rounded

def add_saldo(username,value):
    users = load_users()
    for user in users:
        if user.get('username') == username:
            user['saldo'] += value
            save_user(users)
            break

def remove_saldo(username,value):
    users = load_users()
    for user in users:
        if user.get('username') == username:
            user['saldo'] -= value
            save_user(users)
            break

def aprove_payment(transfer_to,value):
    users = load_users()
    value = convert_value(value)
    if transfer_to == current_user.username:
        return False
    for user in users:
        if user.get('username') == current_user.username:
            saldo = get_user_saldo(user.get('username'))
            if saldo <= int(value):
                return False
            for user in users:
                if user.get('username') == transfer_to:
                    add_saldo(transfer_to,int(value))
                    remove_saldo(current_user.username,int(value))
                    return True
                    break
            return False

if __name__ == '__main__':
    print('you cannot open this module alone.')