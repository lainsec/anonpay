
from flask_session import Session
from modules import database_module
from flask import Flask, render_template, url_for, request, redirect
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user

app = Flask(__name__)

app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = 'secretkey'

login_manager = LoginManager()
login_manager.init_app(app)

class User(UserMixin):
    def __init__(self, username, saldo):
        self.username = username
        self.saldo = saldo

@login_manager.user_loader
def load_user(user_id):
    users = database_module.load_users()
    for user in users:
        if user['username'] == user_id:
            loaded_user = User(user_id, user['saldo'])
            return loaded_user
    return None

@app.route('/')
def main_page():
    return render_template('index.html')

@app.route('/login',methods=["GET","POST"])
def login_page():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if database_module.login_user(username,password):
            user_obj = User(username, database_module.get_user_saldo(username))
            user_obj.id = username
            login_user(user_obj)
            return redirect(url_for('dashboard'))
        else:
            return redirect(url_for('login_page'))

    return render_template('login.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/aprove-payment', methods=["POST"])
@login_required
def aprove_payment():
    transfer_to = request.form['user-field']
    value = request.form['value-field']
    if database_module.aprove_payment(transfer_to,value):
        return redirect(url_for('dashboard'))
    return redirect(url_for('dashboard'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main_page'))

@app.errorhandler(401)
def unauthorized(error):
     return redirect(url_for('main_page')) 

@app.errorhandler(404)
def page_not_found(error):
    return redirect(url_for('main_page'))

if __name__ == '__main__':
    app.run(debug=True,port=80)